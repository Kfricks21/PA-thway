# Plug and play — every click, in order

No terminal, no git commands. This is all done on github.com in a browser, then
one thing in Render. Budget 15 minutes.

You have two folders from me. Only the one called `repo` matters here. Inside it:

```
repo/
  server/
    app.py
    hub.py
    pathway_app.py
    requirements.txt
    pathway/
      index.html
```

The goal: make your repo's `server/` folder contain those same files. That's it.

---

## Part 1 — Put the files in GitHub (10 min)

### Step 1. Open your repo

Go to **github.com/Kfricks21/PA-thway**. Click the **`server`** folder to open it.
You should see `app.py`, `requirements.txt`, and folders like `api`, `models`,
`services`.

### Step 2. Start an upload

Near the top right, click **Add file** → **Upload files**.

### Step 3. Drag in the three new files

From my `repo/server/` folder, drag these **three** files onto the upload box:

- `hub.py`
- `pathway_app.py`
- `requirements.txt`

GitHub will say `requirements.txt` replaces the existing one. That's correct —
it's your file plus one extra line.

**Do not** drag `app.py` yet. It's Step 5.

### Step 4. Commit them

Scroll down. In the box under **Commit changes**, type:

```
Add Student Hub server
```

Click the green **Commit changes** button. Wait for the page to reload.

### Step 5. Replace app.py

You're back in the `server` folder. Click **`app.py`** to open it.

Click the **pencil icon** (top right of the file, "Edit this file").

Select everything in the editor and delete it:
- Windows: click in the code, press **Ctrl+A**, then **Delete**
- Mac: click in the code, press **Cmd+A**, then **Delete**

Now open my `repo/server/app.py` in any text editor (Notepad, TextEdit, VS
Code), select all, copy, and paste it into the empty GitHub editor.

Scroll down, commit message:

```
Mount Hub and student app
```

Click **Commit changes**.

### Step 6. Upload the app itself

This one needs a folder that doesn't exist yet. GitHub creates it for you.

Go back to the **`server`** folder. Click **Add file** → **Upload files**.

Drag in `repo/server/pathway/index.html`.

**Important:** after it uploads, look at the filename field. It will say
`index.html`. Click into it and change it to read exactly:

```
pathway/index.html
```

Typing the `/` is what creates the folder.

It's a 6 MB file, so give it a few seconds. Commit message:

```
Add the student app
```

Click **Commit changes**.

### Step 7. Check your work

Click into `server` → you should now see a **`pathway`** folder alongside
`app.py`, `hub.py`, `pathway_app.py`, `requirements.txt`.

Click `pathway` → `index.html` should be there, and GitHub will say something
like "this file is too large to display". That's expected and fine.

**Render is now already rebuilding.** Every push triggers a deploy.

---

## Part 2 — Give it a database (5 min)

Skip this and the app still works, but everything students post disappears the
next time Render restarts. So don't skip it.

### Step 8. Create the database

In Render, click **New +** (top right) → **Postgres**.

- **Name:** `pathway-db`
- **Plan:** Free
- Leave everything else alone.

Click **Create Database**. Wait until the status says **Available** (a minute or
two).

### Step 9. Copy its address

On that database's page, scroll to **Connections**. Find **Internal Database
URL**. Click the copy icon next to it.

(Internal, not External. Internal is faster and free of egress charges.)

### Step 10. Give it to the app

In Render, open your **web service** (the one that serves your site — not the
database you just made).

Left sidebar → **Environment**. Click **Add Environment Variable**.

- **Key:** `DATABASE_URL`
- **Value:** paste what you copied

Click **Save Changes**. Render redeploys automatically.

---

## Part 3 — Confirm it works (2 min)

Wait for the deploy to finish (**Live** in Render, green).

### Step 11. Is the Hub running?

In your browser, go to:

```
https://YOUR-SERVICE.onrender.com/api/hub/health
```

Replace `YOUR-SERVICE` with your actual Render URL. You want to see:

```json
{"status": "ok", "storage": "postgres", "durable": true}
```

- `"storage": "postgres"` and `"durable": true` → done, correctly.
- `"storage": "sqlite"` → `DATABASE_URL` didn't take. Recheck Step 10, spelling
  included.
- A 404 page → the server files didn't land. Recheck Step 5.

### Step 12. Open the app

```
https://YOUR-SERVICE.onrender.com/app
```

The app loads. Go to **Squad → Notes**. Under the cohort code you should read
**"Live · everyone with this code"**. If it says "On this device only", the app
can't see the Hub — go back to Step 11.

### Step 13. Prove it's shared

Generate a code in the app and write it down. Then open the same `/app` URL on
your **phone** and join with that same code.

Post a note on one device. Within about 5 seconds it appears on the other. That's
the whole point — if that works, you're done.

---

## Sending it to your class

Send them the `/app` link and the cohort code. Tell them to:

1. Open the link on their phone
2. **Share → Add to Home Screen** (iPhone) or **⋮ → Add to Home screen** (Android)
3. Enter their name, then join with the code you gave them

Works on cell data or any WiFi.

---

## If something breaks

**Render deploy fails, log mentions `psycopg`** — `requirements.txt` didn't
update. Redo Step 3 for that one file.

**Render deploy fails, log mentions `No module named 'hub'`** — `hub.py` isn't
in `server/`. It has to sit next to `app.py`, not in a subfolder.

**`/app` shows a blank white page** — the upload was interrupted. Delete
`server/pathway/index.html` on GitHub and redo Step 6.

**Everything worked, then notes vanished** — you're on SQLite. Step 11 will
confirm. Do Part 2.

Paste me the Render log or the health output and I'll read it.
