# Copy these into Kfricks21/PA-thway

Four files, at these exact paths. Nothing else in your repo changes.

| Copy this | To this path in the repo | New or replace |
| --- | --- | --- |
| `server/pathway/index.html` | `server/pathway/index.html` | new (create the folder) |
| `server/hub.py` | `server/hub.py` | new |
| `server/pathway_app.py` | `server/pathway_app.py` | new |
| `server/app.py` | `server/app.py` | **replaces** yours |
| `server/requirements.txt` | `server/requirements.txt` | **replaces** yours |

`app.py` is your existing file with three lines added — the two imports and the
two `register_*(app)` calls just after `app = Flask(__name__)`. Your
`/api/generate`, `/api/health` and the React catch-all are byte-for-byte
unchanged. `requirements.txt` is yours plus `psycopg[binary]`.

Your `render.yaml` needs no edit: the build still runs the client build and pip
install, and `gunicorn --chdir server app:app` picks all of this up because
`--chdir server` puts `hub.py` and `pathway_app.py` on the import path.

## Then, in Render

1. **New → Postgres**, free tier. Copy its **Internal Database URL**.
2. On the web service → **Environment** → add `DATABASE_URL` = that URL.
3. Commit, push. Render redeploys.

Without step 1 the Hub still runs, on SQLite on an ephemeral disk — the class's
notes vanish on the next deploy. `GET /api/hub/health` reports which storage is
live and whether it is durable.

## What the URLs are afterwards

```
https://<your-service>.onrender.com/          your existing React client
https://<your-service>.onrender.com/app       the PA-thway student app
https://<your-service>.onrender.com/api/hub/  the shared Student Hub
```

Send students `/app`. On the phone: open it, then Share → Add to Home Screen.

## Committing a 6 MB HTML file

`server/pathway/index.html` is one self-contained file with fonts and libraries
inlined, so it is about 6 MB. That is under GitHub's 100 MB limit and fine to
commit, but it is a new 6 MB blob in history every time the app changes. If that
bothers you later, the alternative is to serve the app's pieces separately
instead of bundled — say the word and I'll split it.

## Updating the app later

Ask me for a fresh build, replace `server/pathway/index.html`, push. The Hub
server files only change if the Hub's own behaviour changes.
